package com.mycompany.it2024058;

import java.util.Scanner;

/**
 * Complete parking management system with all required features
 * @author frmel
 */
public class it2024058 {
    
    private static EnhancedParkingManager parkingManager;
    private static Scanner scanner;
    
    public static void main(String[] args) {
        scanner = new Scanner(System.in);
        
        // Initialize parking lot
        System.out.println("=== Parking Management System ===");
        System.out.print("Enter total parking spots: ");
        int totalSpots = getPositiveInteger();
        
        System.out.print("Enter electric parking spots: ");
        int electricSpots = getElectricSpots(totalSpots);
        
        parkingManager = new EnhancedParkingManager(totalSpots, electricSpots);
        
        System.out.println("\nParking system initialized with " + totalSpots + " total spots (" + electricSpots + " electric)");
        System.out.println("Sample data has been loaded for testing.\n");
        
        // Main menu loop
        while (true) {
            displayMenu();
            int choice = getMenuChoice();
            
            switch (choice) {
                case 1:
                    parkVehicle();
                    break;
                case 2:
                    removeVehicle();
                    break;
                case 3:
                    searchByDriver();
                    break;
                case 4:
                    searchByVehicle();
                    break;
                case 5:
                    showStatusReport();
                    break;
                case 6:
                    exportToFile();
                    break;
                case 7:
                    System.out.println("Thank you for using the Parking Management System!");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
            
            System.out.println("\nPress Enter to continue...");
            scanner.nextLine();
        }
    }
    
    private static void displayMenu() {
        System.out.println("\n=== MAIN MENU ===");
        System.out.println("1. Park Vehicle");
        System.out.println("2. Remove Vehicle");
        System.out.println("3. Search by Driver Mobile");
        System.out.println("4. Search by License Plate");
        System.out.println("5. Show Parking Status Report");
        System.out.println("6. Export to File");
        System.out.println("7. Exit");
        System.out.print("Choose an option: ");
    }
    
    private static int getMenuChoice() {
        try {
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline
            return choice;
        } catch (Exception e) {
            scanner.nextLine(); // consume invalid input
            return -1;
        }
    }
    
    private static void parkVehicle() {
        System.out.println("\n=== PARK VEHICLE ===");
        
        // Get license plate first to check if vehicle exists
        System.out.print("Enter vehicle license plate: ");
        String licensePlate = scanner.nextLine().trim();
        
        Vehicle vehicle = parkingManager.findVehicleByLicense(licensePlate);
        Driver driver = null;
        
        if (vehicle != null) {
            System.out.println("Vehicle found in system: " + vehicle.getVehicleType() + " (" + vehicle.getFuelType() + ")");
            driver = vehicle.getDriver();
            System.out.println("Driver: " + driver.getFirstName() + " " + driver.getLastName() + " (" + driver.getMobile() + ")");
        } else {
            // Create new vehicle and driver
            System.out.println("New vehicle - please enter details:");
            
            // Get driver info
            System.out.print("Enter driver's mobile number: ");
            String mobile = scanner.nextLine().trim();
            
            driver = parkingManager.findDriverByMobile(mobile);
            if (driver != null) {
                System.out.println("Driver found: " + driver.getFirstName() + " " + driver.getLastName());
            } else {
                System.out.print("Enter driver's first name: ");
                String firstName = scanner.nextLine().trim();
                System.out.print("Enter driver's last name: ");
                String lastName = scanner.nextLine().trim();
                
                driver = new Driver(firstName, lastName, mobile);
                parkingManager.registerDriver(driver);
                System.out.println("New driver registered.");
            }
            
            // Get vehicle info
            String fuelType = getFuelType();
            String vehicleType = getVehicleType();
            
            vehicle = new Vehicle(licensePlate, fuelType, vehicleType, driver) {
                @Override
                public String getDescription() {
                    throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
                }
            };
            parkingManager.registerVehicle(vehicle);
            System.out.println("New vehicle registered.");
        }
        
        // Get parking duration
        System.out.print("Enter parking duration in hours (1-24): ");
        int duration = getParkingDuration();
        
        // Attempt to park the vehicle
        boolean success = parkingManager.parkVehicle(scanner, vehicle, duration);
        
        if (success) {
            System.out.println("Vehicle parked successfully!");
        } else {
            System.out.println("Unable to park vehicle - no suitable spots available.");
        }
    }
    
    private static void removeVehicle() {
        System.out.println("\n=== REMOVE VEHICLE ===");
        System.out.print("Enter license plate of vehicle to remove: ");
        String licensePlate = scanner.nextLine().trim();
        
        boolean success = parkingManager.removeVehicle(licensePlate);
        if (!success) {
            System.out.println("Vehicle not found or not currently parked.");
        }
    }
    
    private static void searchByDriver() {
        System.out.println("\n=== SEARCH BY DRIVER MOBILE ===");
        System.out.print("Enter driver's mobile number: ");
        String mobile = scanner.nextLine().trim();
        
        parkingManager.searchByDriverMobile(mobile);
    }
    
    private static void searchByVehicle() {
        System.out.println("\n=== SEARCH BY LICENSE PLATE ===");
        System.out.print("Enter license plate: ");
        String licensePlate = scanner.nextLine().trim();
        
        parkingManager.searchByLicensePlate(licensePlate);
    }
    
    private static void showStatusReport() {
        parkingManager.generateStatusReport();
    }
    
    private static void exportToFile() {
        System.out.println("\n=== EXPORT TO FILE ===");
        System.out.print("Enter filename (or press Enter for 'parking_status.txt'): ");
        String filename = scanner.nextLine().trim();
        
        if (filename.isEmpty()) {
            filename = "parking_status.txt";
        }
        
        parkingManager.exportToFile(filename);
    }
    
    // Helper methods for input validation
    private static int getPositiveInteger() {
        while (true) {
            try {
                int value = scanner.nextInt();
                scanner.nextLine(); // consume newline
                if (value > 0) {
                    return value;
                }
                System.out.print("Please enter a positive number: ");
            } catch (Exception e) {
                scanner.nextLine(); // consume invalid input
                System.out.print("Please enter a valid number: ");
            }
        }
    }
    
    private static int getElectricSpots(int totalSpots) {
        while (true) {
            try {
                int value = scanner.nextInt();
                scanner.nextLine(); // consume newline
                if (value >= 0 && value <= totalSpots) {
                    return value;
                }
                System.out.print("Electric spots must be between 0 and " + totalSpots + ": ");
            } catch (Exception e) {
                scanner.nextLine(); // consume invalid input
                System.out.print("Please enter a valid number: ");
            }
        }
    }
    
    private static String getFuelType() {
        while (true) {
            System.out.print("Enter fuel type (gas/electric): ");
            String fuelType = scanner.nextLine().trim().toLowerCase();
            if (fuelType.equals("gas") || fuelType.equals("electric")) {
                return fuelType;
            }
            System.out.println("Invalid input. Please enter 'gas' or 'electric'.");
        }
    }
    
    private static String getVehicleType() {
        while (true) {
            System.out.print("Enter vehicle type (car/motorcycle/truck): ");
            String vehicleType = scanner.nextLine().trim().toLowerCase();
            if (vehicleType.equals("car") || vehicleType.equals("motorcycle") || vehicleType.equals("truck")) {
                return vehicleType;
            }
            System.out.println("Invalid input. Please enter 'car', 'motorcycle', or 'truck'.");
        }
    }
    
    private static int getParkingDuration() {
        while (true) {
            try {
                int duration = scanner.nextInt();
                scanner.nextLine(); // consume newline
                if (duration >= 1 && duration <= 24) {
                    return duration;
                }
                System.out.print("Duration must be between 1 and 24 hours: ");
            } catch (Exception e) {
                scanner.nextLine(); // consume invalid input
                System.out.print("Please enter a valid number: ");
            }
        }
    }
}