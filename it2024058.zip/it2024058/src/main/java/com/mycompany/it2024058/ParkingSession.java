/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author frmel
 */
package com.mycompany.it2024058;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

/**
 * Represents a parking session with start time, duration, and cost calculation
 * @author frmel
 */
public class ParkingSession {
    private Vehicle vehicle;
    private Driver driver;
    private int[] spotIds; // Array to handle trucks using 2 spots
    private LocalDateTime startTime;
    private int durationHours;
    private double cost;
    private boolean isActive;
    private LocalDateTime endTime;
    
    public ParkingSession(Vehicle vehicle, Driver driver, int[] spotIds, int durationHours) {
        this.vehicle = vehicle;
        this.driver = driver;
        this.spotIds = spotIds;
        this.startTime = LocalDateTime.now();
        this.durationHours = durationHours;
        this.cost = calculateCost(durationHours);
        this.isActive = true;
        this.endTime = null;
    }
    
    /**
     * Calculate parking cost based on duration
     * Up to 3 hours = 5€
     * 4-8 hours = 8€
     * 9-23 hours = 12€
     * 24 hours = 15€
     */
    private double calculateCost(int hours) {
        if (hours <= 3) return 5.0;
        if (hours <= 8) return 8.0;
        if (hours <= 23) return 12.0;
        return 15.0; // 24 hours
    }
    
    /**
     * End the parking session
     */
    public void endSession() {
        this.isActive = false;
        this.endTime = LocalDateTime.now();
        
        // Recalculate cost based on actual time if needed
        long actualHours = ChronoUnit.HOURS.between(startTime, endTime);
        if (actualHours > durationHours) {
            this.cost = calculateCost((int) actualHours);
        }
    }
    
    // Getters and setters
    public Vehicle getVehicle() { return vehicle; }
    public Driver getDriver() { return driver; }
    public int[] getSpotIds() { return spotIds; }
    public LocalDateTime getStartTime() { return startTime; }
    public int getDurationHours() { return durationHours; }
    public double getCost() { return cost; }
    public boolean isActive() { return isActive; }
    public LocalDateTime getEndTime() { return endTime; }
    
    public String getFormattedStartTime() {
        return startTime.format(DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm"));
    }
    
    public String getFormattedEndTime() {
        return endTime != null ? endTime.format(DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm")) : "Active";
    }
    
    @Override
    public String toString() {
        return String.format("License: %s, Driver: %s %s, Phone: %s, Start: %s, Duration: %dh, Cost: %.2f€, Spots: %s",
            vehicle.getLicensePlate(),
            driver.getFirstName(),
            driver.getLastName(),
            driver.getMobile(),
            getFormattedStartTime(),
            durationHours,
            cost,
            java.util.Arrays.toString(spotIds)
        );
    }
}