/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.it2024058;

/**
 *
 * @author frmel
 */

import java.util.Scanner;

public class ParkingManager {

    public static boolean assignSpotToVehicle(Scanner scanner, Vehicle vehicle, ParkingLot parkingLot) {
        ParkingSpot[] spots = parkingLot.getSpots();
        boolean assigned = false;

        boolean wantsElectric = false;
        if (vehicle.getFuelType().equals("electric")) {
            System.out.print("Do you want to park in an electric spot? (yes/no): ");
            wantsElectric = scanner.nextLine().trim().equalsIgnoreCase("yes");
        }

        for (int i = 0; i < spots.length; i++) {
            ParkingSpot spot = spots[i];
            if (spot.isOccupied()) continue;

            // TRUCK logic (needs two consecutive spots)
            if (vehicle.getVehicleType().equals("truck")) {
                if (i + 1 >= spots.length) continue; // no room for second spot

                ParkingSpot nextSpot = spots[i + 1];
                if (nextSpot.isOccupied()) continue;

                // Electric truck wants electric spots
                if (vehicle.getFuelType().equals("electric") && wantsElectric) {
                    if (spot.isForElectric() && nextSpot.isForElectric()) {
                        spot.occupy(vehicle);
                        nextSpot.occupy(vehicle);
                        System.out.println("Electric truck assigned to electric spots " + spot.getSpotId() + " and " + nextSpot.getSpotId() + "\n");
                        assigned = true;
                        break;
                    } else {
                        continue; // both spots must be electric
                    }
                }

                // Gas or electric not wanting electric spots trucks assigned to regular spots
                if (!spot.isForElectric() && !nextSpot.isForElectric()) {
                    spot.occupy(vehicle);
                    nextSpot.occupy(vehicle);
                    System.out.println("Truck assigned to regular spots " + spot.getSpotId() + " and " + nextSpot.getSpotId() + "\n");
                    assigned = true;
                    break;
                }
                continue;
            }

            // ELECTRIC non-truck
            if (vehicle.getFuelType().equals("electric")) {
                if (wantsElectric && spot.isForElectric()) {
                    spot.occupy(vehicle);
                    System.out.println("Driver assigned to electric spot " + spot.getSpotId() + "\n");
                    assigned = true;
                    break;
                } else if (!wantsElectric && !spot.isForElectric()) {
                    spot.occupy(vehicle);
                    System.out.println("Driver assigned to regular spot " + spot.getSpotId() + "\n");
                    assigned = true;
                    break;
                }
            }
            // GAS vehicles (car/motorcycle)
            else {
                if (!spot.isForElectric()) {
                    spot.occupy(vehicle);
                    System.out.println("Driver assigned to regular spot " + spot.getSpotId() + "\n");
                    assigned = true;
                    break;
                }
            }
        }
        return assigned;
    }

    public static boolean removeVehicleByLicense(String licensePlate, ParkingLot parkingLot) {
        ParkingSpot[] spots = parkingLot.getSpots();

        for (int i = 0; i < spots.length; i++) {
            ParkingSpot spot = spots[i];
            if (spot.isOccupied() && spot.getVehicle() != null &&
                spot.getVehicle().getLicensePlate().equalsIgnoreCase(licensePlate)) {

                Vehicle vehicle = spot.getVehicle();

                // Vacate this spot
                spot.vacate();
                spot.setVehicle(null);

                // If truck, vacate the next spot as well
                if (vehicle.getVehicleType().equals("truck")) {
                    if (i + 1 < spots.length) {
                        ParkingSpot nextSpot = spots[i + 1];
                        if (nextSpot.isOccupied() && nextSpot.getVehicle() == vehicle) {
                            nextSpot.vacate();
                            nextSpot.setVehicle(null);
                        }
                    }
                }

                System.out.println("Vehicle with license plate " + licensePlate + " has been removed.");
                return true;
            }
        }
        return false;  // Vehicle not found
    }
}

