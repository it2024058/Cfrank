/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.it2024058;

/**
 *
 * @author frmel
 */
public class Vehicle {
    protected String licensePlate;
    protected int size; // 1 for Car/Motorcycle
    protected String fuelType;
    String vehicleType;
    protected Driver driver;

    public Vehicle(String licensePlate, String fuelType, String vehicleType, Driver driver) {
        this.licensePlate = licensePlate;
        this.size = 1;
        this.fuelType = fuelType;
        this.vehicleType = vehicleType;
        this.driver = driver;
    }

    public boolean isElectric(String vehicleType) {
        return vehicleType .equals("Electric");
    }

    public int getSize() {
        return size;
    }

    public String getLicensePlate() {
        return licensePlate;
    }

    public void setLicensePlate(String licensePlate) {
        this.licensePlate = licensePlate;
    }

    public String getFuelType() {
        return fuelType;
    }

    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public Driver getDriver() {
        return driver;
    }

    public void setDriver(Driver driver) {
        this.driver = driver;
    }

    
}

