/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.it2024058;

/**
 *
 * @author frmel
 */
public class ParkingSpot {
    private int spotId;
    private boolean isForElectric;
    private Vehicle parkedVehicle;  // null if empty

    public ParkingSpot(int spotId, boolean isForElectric) {
        this.spotId = spotId;
        this.isForElectric = isForElectric;
        this.parkedVehicle = null;
    }

    // Check if spot can be used by this vehicle (spot must be free, and fuel type compatible)
    public boolean canBeUsedBy(Vehicle vehicle) {
        if (isOccupied()) return false;
        if (isForElectric) {
            // Electric spots can be used by electric vehicles
            return vehicle.getFuelType().equalsIgnoreCase("electric");
        } else {
            // Regular spots can be used by gas vehicles, or by electric vehicles not requesting electric spot
            return true; // you may refine logic if needed
        }
    }

    public void occupy(Vehicle vehicle) {
        this.parkedVehicle = vehicle;
    }

    public void vacate() {
        this.parkedVehicle = null;
    }

    public boolean isOccupied() {
        return parkedVehicle != null;
    }

    public int getSpotId() {
        return spotId;
    }

    public boolean isForElectric() {
        return isForElectric;
    }

    public Vehicle getVehicle() {
        return parkedVehicle;
    }

    public void setVehicle(Vehicle vehicle) {
        this.parkedVehicle = vehicle;
    }
}

