/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.it2024058;

import java.util.Scanner;

/**
 *
 * @author frmel
 */
public class ParkingLot {
    private ParkingSpot[] spots;

    
    public ParkingLot(int totalSpots, int electricSpots) {
        spots = new ParkingSpot[totalSpots];
        int regularSpots = totalSpots - electricSpots;

        for (int i = 0; i < totalSpots; i++) {
            boolean isElectric = (i >= regularSpots);  // last electricSpots are for electric vehicles
            spots[i] = new ParkingSpot(i + 1, isElectric);
        }
    }

    public ParkingSpot[] getSpots() {
        return spots;
    }

    public boolean isFull() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

