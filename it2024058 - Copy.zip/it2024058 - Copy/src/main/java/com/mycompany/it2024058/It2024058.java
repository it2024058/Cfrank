/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.it2024058;

import java.util.Scanner;

public class It2024058 {

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {

            // Get parking lot size
            int totalSpots = getTotalSpots(scanner);
            int electricSpots = getElectricSpots(scanner, totalSpots);

            ParkingLot parkingLot = new ParkingLot(totalSpots, electricSpots);
            int driversAdded = 0;

            while (driversAdded < totalSpots) {
                Vehicle vehicle = collectVehicleInfo(scanner);
                boolean assigned = ParkingManager.assignSpotToVehicle(scanner, vehicle, parkingLot);

                if (!assigned) {
                    System.out.println("No available spot for this vehicle.\n");
                    break;
                }

                driversAdded++;

                // Ask if user wants to continue adding vehicles
                System.out.print("Do you want to add another vehicle? (yes/no): ");
                String answer = scanner.nextLine().trim().toLowerCase();
                if (!answer.equals("yes")) {
                    System.out.println("Stopping input as requested.");
                    break;
                }
            }

            System.out.println("Parking lot is full or no suitable spots remain.");
        }
    }

    private static int getTotalSpots(Scanner scanner) {
        System.out.print("Give me the total Parking Spots: ");
        int totalSpots = scanner.nextInt();
        scanner.nextLine(); // consume newline

        while (totalSpots <= 0) {
            System.out.println("Total parking spots must be a positive number.");
            System.out.print("Give me the total Parking Spots: ");
            totalSpots = scanner.nextInt();
            scanner.nextLine();
        }
        return totalSpots;
    }

    private static int getElectricSpots(Scanner scanner, int totalSpots) {
        int electricSpots = -1;
        while (electricSpots > totalSpots || electricSpots < 0) {
            System.out.print("Give me the Electric Parking Spots: ");
            electricSpots = scanner.nextInt();
            scanner.nextLine();

            if (electricSpots > totalSpots) {
                System.out.println("Electric parking spots cannot be greater than total parking spots.");
            } else if (electricSpots < 0) {
                System.out.println("Electric parking spots cannot be negative.");
            }
        }
        return electricSpots;
    }

    private static Vehicle collectVehicleInfo(Scanner scanner) {
        // Get driver info
        System.out.print("Enter driver's first name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter driver's last name: ");
        String lastName = scanner.nextLine();

        System.out.print("Enter driver's mobile number: ");
        String mobile = scanner.nextLine();

        Driver driver = new Driver(firstName, lastName, mobile);

        // Get vehicle info
        System.out.print("Enter vehicle license plate: ");
        String licensePlate = scanner.nextLine();

        String fuelType = "";
        while (true) {
            System.out.print("Enter fuel type (gas/electric): ");
            fuelType = scanner.nextLine().toLowerCase();
            if (fuelType.equals("gas") || fuelType.equals("electric")) break;
            System.out.println("Invalid input. Please enter 'gas' or 'electric'.");
        }

        String vehicleType = "";
        while (true) {
            System.out.print("Enter vehicle type (truck/car/motorcycle): ");
            vehicleType = scanner.nextLine().toLowerCase();
            if (vehicleType.equals("truck") || vehicleType.equals("car") || vehicleType.equals("motorcycle")) break;
            System.out.println("Invalid input. Please enter 'truck', 'car', or 'motorcycle'.");
        }

        return new Vehicle(licensePlate, fuelType, vehicleType, driver);
    }
}
